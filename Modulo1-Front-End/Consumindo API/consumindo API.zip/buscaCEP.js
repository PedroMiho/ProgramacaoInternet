//DOM
const cep = document.querySelector("#cep")


//Adiciona um evento no elemento
cep.addEventListener("change" ,  (evento) => {
    //Impede que a página seja recarregada
    let cep = evento.target

    //Captura o valor do CEP digitado
    console.log(cep.value);
    buscaCep(cep.value)
})
